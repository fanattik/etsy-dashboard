# Etsy Dashboard

A small local dashboard for Etsy sellers: orders, revenue, Etsy fees, payouts and what still needs to ship, for one or more shops in one place. It runs on your own computer and opens in the browser; your data and keys never leave your machine (except for requests to Etsy).

![Dashboard](docs/screenshot.png)

The interface is available in English, Czech and German (switch in *Settings*, which also has currency and light or dark theme; it follows your browser language by default). A step-by-step guide in Czech is in [docs/NAVOD.md](docs/NAVOD.md).

## Features

- Revenue, order count, average order, Etsy fees (incl. VAT), net to account, payouts, balance and orders waiting to ship
- Monthly revenue chart (12 months), best sellers, fee breakdown
- Orders and payment-account tables with filters, sorting and CSV export (Excel-friendly)
- Per-order shipping notes: carrier, tracking number and your shipping cost (kept locally, never overwritten by imports)
- Your own order states (Settings → Order states, default New → In production → Ready → Shipped): name, color, order, final state, and a simple rule for when an order moves there on its own (paid, shipped in the channel, has tracking, has personalization, only digital products, from one account). Change a state in the order detail or for several orders at once; a state can send the tracking number to Etsy when you move orders into it by hand, and notify your phone when orders move there on their own
- Send the carrier and tracking number to Etsy from the order detail (Etsy marks the order shipped and emails the buyer). Needs the shop signed in again once, for the new `transactions_w` permission
- Printable production sheet for the selected orders, or for all shown orders not in a final state: totals per product and variant, then each order with variant and personalization (digital items left out)
- Order details list each item with its variant and personalization and link to the catalog product. Products in stock mode lower their variant stock after a sale and flag their offers until the new quantity is sent through the edit form
- Products page (catalog): every product once, with its photos, download files, variants, per-channel data and the listings that offer it. Adopt existing Etsy listings into the catalog (photos are downloaded, the Etsy data is kept as that shop's layer) or load a folder of products; neither changes anything on Etsy. Each product can be edited: general data and base price, variants with SKU and stock, photos and files, and its text, tags, category and price for all of Etsy or for one shop
- Publish catalog products to one or more Etsy shops: the new listing form opens prefilled from the catalog (shop layer, Etsy layer, product, shop rules) with local photos and files, and the created listing is linked to the product. The catalog flags offers with unsent catalog changes (send them through the edit form) and listings changed directly on Etsy (take them into the catalog)
- Sell through your own web shop: any shop that implements the small [Custom API](docs/custom-api.md) can be added in *Settings → Web shops via custom API*. Catalog products are published and updated there with a button, the shop's orders and product changes are downloaded on every check, and tracking numbers are sent back from the order detail. [`examples/custom_api_server.py`](examples/custom_api_server.py) is a complete reference shop to try it with or to copy from
- Catalog settings: base currency, catalog language and rules per sales account (price multiplier and rounding from the ECB rate, made-to-order quantity, photo limit, description footer, default shipping, processing and category)
- Listings page: price, stock, views, favorites, and units sold and revenue per listing in the selected period
- Create new listings through the Etsy API: load a folder of products (each with an `etsy-listing.md`, images and download files), check and edit them, then create drafts or publish them in one go. Each listing can be digital (download files) or physical (shipping and processing profiles), with category attributes, up to two variations with their own price, quantity and SKU, and custom options for the buyer (personalization questions: text, dropdown or file upload)
- Edit existing listings (text, price, images, files, attributes, variations), activate, deactivate or delete them, one at a time or several at once
- Scheduled sales from a start to an end date. The Etsy API has no Sales & Discounts endpoints, so the dashboard lowers the prices on the start day and restores them after the end (only while it runs)
- Stats page: listing views, orders, conversion and revenue charts, new favorites, shop followers, reviews, repeat buyers, cities and countries, and listings ranked by views. The Etsy API only reports lifetime view counts, so the dashboard stores a daily snapshot and the history starts on the first day it runs (visits and traffic sources are not available through the API)
- Several shops side by side, filter by shop and period
- Show all amounts in one currency of your choice (converted at the daily ECB rate)
- Two ways to get data:
  - **CSV import** (works right away): upload the files from *Shop Manager → Settings → Options → Download Data* (Payment Account statements, Orders, Order Items, Payments, Currently for Sale Listings). Re-uploading the same file never duplicates anything.
  - **Etsy Open API v3** (automatic every 15 minutes) once your Etsy developer app is approved
- New-order notifications in the browser, optionally on your phone via [ntfy](https://ntfy.sh)
- Updates itself from this repository once a day

## Install on macOS

1. Download [Etsy-Dashboard-mac.zip](https://github.com/fanattik/etsy-dashboard/raw/main/dist/Etsy-Dashboard-mac.zip), unzip it and move **Etsy Dashboard** to *Applications*.
2. Open it. The app is not signed with an Apple Developer ID, so macOS blocks the first launch: click *Done*, then go to *System Settings → Privacy & Security* and click *Open Anyway*. This is needed only once.
3. If Python 3 is missing, the app offers to download it from python.org.

The app installs a background service (LaunchAgent) that starts at login, so afterwards the dashboard is always at <http://127.0.0.1:8765>. Uninstall from the dashboard: *Settings → Uninstall*.

## Run anywhere else

Only the Python 3.9+ standard library is needed:

```sh
python3 app/etsy_dashboard.py          # start and open the browser
python3 app/etsy_dashboard.py demo     # demo data, port 8766
python3 app/etsy_dashboard.py jednou   # one API sync without the UI (cron)
```

## Connecting the Etsy API

1. Register an app at <https://www.etsy.com/developers/register>.
2. Add the callback URL `https://localhost:3003/etsy`.
3. After Etsy approves it, paste the *Keystring* and *Shared secret* into *Settings* and sign in each shop. The browser then shows a "can't connect" page; copy the full address from the address bar back into the dashboard.

## Project layout

| Path | What |
| --- | --- |
| `app/etsy_dashboard.py` | entry point: local web server, background sync loop, self-update, `VERSION` |
| `app/zaklad.py` | paths, constants, settings, tokens, HTTP helper |
| `app/databaze.py` | SQLite schema and helpers |
| `app/etsy_api.py` | Etsy Open API v3: OAuth sign-in and API calls |
| `app/synchronizace.py` | sync of orders, payment account, listings and stats from Etsy, ECB rates |
| `app/etsy_listingy.py` | creating and editing listings, personalization, scheduled sales |
| `app/katalog.py` | product catalog: adopting listings, loading product folders, media files in `data/media` |
| `app/produkty.py` | editing catalog products, variants, media and channel layers; account rules and price calculation |
| `app/nabidky.py` | offers: data for publishing a product to a shop, linking created listings, change detection, taking changes from Etsy |
| `app/objednavky.py` | order states and their rules, manual state changes, sending tracking to Etsy, stock after a sale |
| `app/kanal_api.py` | the Custom API channel: shop accounts, publishing products, downloading products and orders, sending tracking |
| `app/prehled.py` | data for the dashboard and stats pages, CSV export, shipping notes, demo data |
| `app/csv_import.py` | import of CSV files downloaded from Etsy |
| `app/dashboard.html` | the dashboard UI (no build step, no external libraries) |
| `docs/custom-api.md` | specification of the Custom API a web shop implements |
| `examples/custom_api_server.py` | reference implementation of the Custom API (standard library only) |
| `app/version.json` | version used by the self-updater |
| `mac/launcher.sh`, `mac/build_mac_app.py` | macOS app bundle and its build script (`python3 mac/build_mac_app.py`, needs Pillow for the icon) |
| `dist/Etsy-Dashboard-mac.zip` | built macOS app |

## Releasing an update

Bump `VERSION` in `app/etsy_dashboard.py`, run `python3 mac/build_mac_app.py` (it also rewrites `app/version.json` and the zip) and push to `main`. Installed apps pick it up within a day.

## License

[MIT](LICENSE)
